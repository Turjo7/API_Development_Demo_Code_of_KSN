<?php
// Required Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
  

// Include Database & Object Files
include_once '../config/database.php';
include_once '../objects/events.php';




$database = new Database();
$db = $database->getConnection();
  
// Initialize Object
$events = new Events($db);
  




// Query Events
$stmt = $events->read();
$num = $stmt->rowCount();
  
// Check If More Than 0 Records Found
if($num>0){
  
    // Events Array
    $events_arr=array();
    $events_arr["events"]=array();
  
    // Retrieve Table of Contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // Extract Row
        // It Will Make $row['name'] to
        // just $name only
        extract($row);
  
        $events_item=array(
            "event_id" => $event_id,
            "admin_id" => $admin_id,
            //"description" => html_entity_decode($description),
            /*entity decode would be needed in future */
            
            "event_name" => $event_name,
            "event_time" => $event_time,
            "event_date" => $event_date,
            "event_topics" => $event_topics

        );
  
        array_push($events_arr["events"], $events_item);
    }
  
    // Set Response Code -> 200 OK
    http_response_code(200);
  
    // Show Events Data in JSON Format
    echo json_encode($events_arr);
}
  
else{
  
    // Set Response Code - 404 Not Found
    http_response_code(404);
  
    // If There Is No Event Them Show
    echo json_encode(
        array("message" => "No Events Found.")
    );
}

?>